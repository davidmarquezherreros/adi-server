Tutoriales:
https://www.tutorialspoint.com/nodejs/nodejs_express_framework.htm

http://cwbuecheler.com/web/tutorials/2013/node-express-mongo/

https://shapeshed.com/creating-a-basic-site-with-node-and-express/

https://geekytheory.com/introduccion-a-express-js/
